// GET  /api/admin/expenses — list operating expenses
// POST /api/admin/expenses — create an operating expense
import { type NextRequest, NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/admin-auth'
import { sql } from '@/lib/db'
import { createExpenseService, validateExpenseInput } from '@/lib/expenses'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const { error } = await requireAdmin(req)
  if (error) return error
  try {
    return NextResponse.json({ expenses: await createExpenseService(sql).listExpenses() })
  } catch (err: any) {
    console.error('[admin/expenses GET]', err?.message?.slice(0, 120))
    return NextResponse.json({ error: 'Could not load expenses.' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const { identity, error } = await requireAdmin(req)
  if (error) return error

  let body: any
  try { body = await req.json() } catch {
    return NextResponse.json({ error: 'Invalid request body.' }, { status: 400 })
  }

  const input = {
    name:        typeof body.name === 'string' ? body.name : '',
    category:    body.category,
    vendor:      body.vendor || null,
    description: body.description || null,
    amountCents: body.amountCents === null || body.amountCents === undefined
      ? NaN : Number(body.amountCents),
    recurrence:  body.recurrence,
    expenseDate: body.expenseDate,
    endedOn:     body.endedOn || null,
    active:      body.active !== false,
    notes:       body.notes || null,
  }

  const v = validateExpenseInput(input as any)
  if (!v.ok) return NextResponse.json({ error: v.error }, { status: 400 })

  try {
    const created = await createExpenseService(sql).createExpense(input as any, identity!.email)
    await sql`
      INSERT INTO admin_audit_logs (actor_email, action, resource, resource_id, payload)
      VALUES (${identity!.email}, 'create', 'operating_expense', ${created.id},
              ${JSON.stringify({ name: input.name, amountCents: input.amountCents,
                                 recurrence: input.recurrence })}::jsonb)
    `
    return NextResponse.json({ expense: created }, { status: 201 })
  } catch (err: any) {
    console.error('[admin/expenses POST]', err?.message?.slice(0, 120))
    return NextResponse.json({ error: 'Could not create expense.' }, { status: 500 })
  }
}
