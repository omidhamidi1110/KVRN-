// PATCH  /api/admin/expenses/[id] — update an operating expense
// DELETE /api/admin/expenses/[id] — remove an operating expense
import { type NextRequest, NextResponse } from 'next/server'
import { requireAdmin } from '@/lib/admin-auth'
import { sql } from '@/lib/db'
import { createExpenseService, validateExpenseInput } from '@/lib/expenses'

export const dynamic = 'force-dynamic'
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i

const ALLOWED = ['name','category','vendor','description','amountCents',
                 'recurrence','expenseDate','endedOn','active','notes']

export async function PATCH(
  req: NextRequest, { params }: { params: Promise<{ id: string }> }
) {
  const { identity, error } = await requireAdmin(req)
  if (error) return error
  const { id } = await params
  if (!UUID_RE.test(id)) return NextResponse.json({ error: 'Invalid id.' }, { status: 400 })

  let body: any
  try { body = await req.json() } catch {
    return NextResponse.json({ error: 'Invalid request body.' }, { status: 400 })
  }

  // Allowlist: never let the client set created_by, id or timestamps.
  const patch: any = {}
  for (const k of ALLOWED) if (body[k] !== undefined) patch[k] = body[k]
  if (patch.amountCents !== undefined) patch.amountCents = Number(patch.amountCents)

  // Validate only the fields actually supplied.
  if (patch.amountCents !== undefined &&
      (!Number.isInteger(patch.amountCents) || patch.amountCents < 0)) {
    return NextResponse.json({ error: 'Amount must be a non-negative whole number of cents.' }, { status: 400 })
  }
  if (patch.name !== undefined || patch.category !== undefined || patch.recurrence !== undefined) {
    const probe = {
      name:        patch.name        ?? 'placeholder',
      category:    patch.category    ?? 'other',
      recurrence:  patch.recurrence  ?? 'one_time',
      amountCents: patch.amountCents ?? 0,
      expenseDate: patch.expenseDate ?? '2000-01-01',
      endedOn:     patch.endedOn     ?? null,
    }
    const v = validateExpenseInput(probe as any)
    if (!v.ok) return NextResponse.json({ error: v.error }, { status: 400 })
  }

  try {
    const ok = await createExpenseService(sql).updateExpense(id, patch)
    if (!ok) return NextResponse.json({ error: 'Expense not found.' }, { status: 404 })
    await sql`
      INSERT INTO admin_audit_logs (actor_email, action, resource, resource_id, payload)
      VALUES (${identity!.email}, 'update', 'operating_expense', ${id}, ${JSON.stringify(patch)}::jsonb)
    `
    return NextResponse.json({ ok: true })
  } catch (err: any) {
    console.error('[admin/expenses PATCH]', err?.message?.slice(0, 120))
    return NextResponse.json({ error: 'Could not update expense.' }, { status: 500 })
  }
}

export async function DELETE(
  req: NextRequest, { params }: { params: Promise<{ id: string }> }
) {
  const { identity, error } = await requireAdmin(req)
  if (error) return error
  const { id } = await params
  if (!UUID_RE.test(id)) return NextResponse.json({ error: 'Invalid id.' }, { status: 400 })

  try {
    const ok = await createExpenseService(sql).deleteExpense(id)
    if (!ok) return NextResponse.json({ error: 'Expense not found.' }, { status: 404 })
    await sql`
      INSERT INTO admin_audit_logs (actor_email, action, resource, resource_id, payload)
      VALUES (${identity!.email}, 'delete', 'operating_expense', ${id}, '{}'::jsonb)
    `
    return NextResponse.json({ ok: true })
  } catch (err: any) {
    console.error('[admin/expenses DELETE]', err?.message?.slice(0, 120))
    return NextResponse.json({ error: 'Could not delete expense.' }, { status: 500 })
  }
}
